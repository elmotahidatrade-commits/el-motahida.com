/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#f8f9fb',
        sidebar: '#0a1a3a',
        sidebarActive: '#1565C0',
        cardBorder: '#e5e7eb'
      }
    },
  },
  plugins: [],
}
