const mongoose = require('mongoose');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const User = require('./models/User');
const SiteSettings = require('./models/SiteSettings');

dotenv.config();

const seedData = async () => {
  try {
    await connectDB();

    // Clear existing data to prevent duplicates during initial seed
    await User.deleteMany();
    await SiteSettings.deleteMany();

    // 1. Create Super Admin User
    const superAdmin = new User({
      name: 'Super Admin',
      email: 'admin@elmotahida.com',
      password: 'password123', // Will be hashed by pre-save hook
      role: 'superadmin',
    });
    await superAdmin.save();

    // 2. Insert User-Provided Site Settings
    const settings = new SiteSettings({
      phone: '+20118964175',
      email: 'Hamedsamaha75@gmail.com',
      address: {
        en: 'El Motahida Trade',
        ar: 'المتحدة للتجارة',
      },
      metaTags: {
        commercialRegister: '107908', // س.ت
        taxId: '777108933', // ب.ض
        landline: '0473861560',
      },
      stats: [
        { value: '5+', label_en: 'Decades', label_ar: 'عقود' },
        { value: '52+', label_en: 'Projects', label_ar: 'مشاريع' },
        { value: '75+', label_en: 'Countries', label_ar: 'دولة' },
      ],
    });
    await settings.save();

    console.log('Data Imported successfully!');
    process.exit();
  } catch (error) {
    console.error(`Error with data import: ${error.message}`);
    process.exit(1);
  }
};

seedData();
