const mongoose = require('mongoose');

const siteSettingsSchema = new mongoose.Schema({
  phone: { type: String },
  email: { type: String },
  address: {
    ar: { type: String },
    en: { type: String }
  },
  socialLinks: { type: Map, of: String },
  metaTags: { type: Map, of: String },
  stats: [{
    value: { type: String },
    label_ar: { type: String },
    label_en: { type: String }
  }]
}, { timestamps: true });

const SiteSettings = mongoose.model('SiteSettings', siteSettingsSchema);
module.exports = SiteSettings;
