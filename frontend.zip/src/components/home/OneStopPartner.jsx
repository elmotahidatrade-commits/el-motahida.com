import React from 'react';
import { ArrowRight, Check } from 'lucide-react';

const OneStopPartner = () => {
  return (
    <section className="bg-white py-[80px] px-4 md:px-[5%] w-full">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        {/* Left Column: Photo Frame */}
        <div className="relative rounded-[8px] overflow-hidden shadow-md h-full min-h-[400px]">
          <img 
            src="https://images.unsplash.com/photo-1565106430482-8f6e74349ca1?auto=format&fit=crop&q=80" 
            alt="Industrial Excellence" 
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>

        {/* Right Column: Content */}
        <div className="flex flex-col">
          <h2 className="text-[28px] font-bold text-[#1a2035] leading-tight font-display">
            Your One-Stop Technology Partner
          </h2>
          <h3 className="text-[16px] text-primary font-semibold mt-2 mb-4 font-sans">
            Engineering excellence from concept to commissioning
          </h3>
          <div className="text-[14px] text-text-muted leading-[1.75] font-sans space-y-4">
            <p>
              We deliver complete turnkey solutions designed to elevate your industrial operations. With decades of hands-on expertise, our dedicated engineers ensure optimal performance tailored directly to your specific market demands.
            </p>
          </div>

          {/* Pills Row */}
          <div className="flex flex-wrap gap-[10px] mt-5">
            {[
              "In-house R&D", 
              "Dedicated Foundry", 
              "World-class Mfg.", 
              "Eco-friendly"
            ].map(item => (
              <div key={item} className="border-[1.5px] border-primary rounded-full px-[14px] py-[6px] text-primary text-[13px] font-medium flex items-center gap-x-2">
                <div className="w-[6px] h-[6px] rounded-full bg-accent"></div>
                {item}
              </div>
            ))}
          </div>

          {/* CTA Button */}
          <button className="bg-primary hover:bg-[#0d47a1] transition-colors text-white px-6 py-3 rounded-[4px] font-semibold text-[14px] flex items-center justify-center gap-x-2 mt-6 w-fit shadow-md">
            Discover Our Story
            <ArrowRight size={16} />
          </button>

        </div>
      </div>
    </section>
  );
};

export default OneStopPartner;
