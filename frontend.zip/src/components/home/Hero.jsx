import React from 'react';
import { ArrowRight, Play, Mouse } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative w-full h-[calc(100vh-36px)] bg-navy-deep overflow-hidden">
      {/* Background Image & Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center w-full h-full mix-blend-overlay"
        style={{ backgroundImage: `url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80')` }}
      />
      <div className="absolute inset-0 bg-[#050f1e]/85 shadow-[inset_0_0_150px_rgba(21,101,192,0.15)]" />
      
      {/* Blue Wireframe Effect over machinery */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-color-dodge filter hue-rotate-15 brightness-150"
        style={{ backgroundImage: `url('https://images.unsplash.com/photo-1581091226033-bb2a4ce16e78?auto=format&fit=crop&q=80')` }}
      />

      {/* Hero Content */}
      <div className="absolute bottom-[30%] left-[5%] z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-white font-display font-bold text-[clamp(36px,4.5vw,58px)] leading-[1.15] tracking-tight">
          Complete Technology<br />
          Solutions for<br />
          Industrial Trade
        </h1>
        <p className="text-white/80 text-[15px] max-w-[480px] mt-6 leading-relaxed font-sans">
          Engineering excellence from concept to commissioning. Discover integrated solutions designed to drive your production forward.
        </p>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-4 mt-8">
          <button className="bg-primary hover:bg-[#0d47a1] transition-colors text-white px-7 py-3 rounded-md font-semibold text-[14px] flex items-center justify-center gap-x-2 shadow-lg shadow-primary/25">
            Explore Products
            <ArrowRight size={16} />
          </button>
          <button className="bg-transparent border-[1.5px] border-white/70 hover:bg-white/10 transition-colors text-white px-7 py-[10px] rounded-md font-semibold text-[14px] flex items-center justify-center gap-x-2">
            <div className="flex items-center justify-center bg-white text-navy-deep rounded-full p-[2px]">
              <Play size={12} className="ml-[2px]" fill="currentColor" />
            </div>
            Watch Video
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-y-2 opacity-70 animate-bounce">
        <Mouse size={24} className="text-white" />
      </div>
    </div>
  );
};

export default Hero;
