import React, { useState, useEffect } from 'react';
import { Globe, ChevronDown, Search } from 'lucide-react';

const Navbar = () => {
  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 36) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    'Home', 'Products', 'Solutions', 'Projects', 'About', 'Contact'
  ];

  return (
    <nav className={`w-full bg-white transition-all duration-300 z-40 ${isSticky ? 'fixed top-0 shadow-[0_2px_8px_rgba(0,0,0,0.08)]' : 'relative'} h-[64px] flex items-center justify-between px-10`}>
      
      {/* LOGO */}
      <div className="flex items-center gap-x-2">
        <Globe className="text-primary h-8 w-8" />
        <span className="font-display font-bold text-text-dark text-xl tracking-tight">EL-MOTAHIDA TRADE</span>
      </div>

      {/* NAV LINKS */}
      <div className="hidden md:flex items-center gap-x-[16px]">
        {navLinks.map((link) => (
          <div key={link} className="flex items-center gap-x-1 cursor-pointer group">
            <span className="text-[14px] text-[#1a2035] font-medium group-hover:text-primary transition-colors">
              {link}
            </span>
            <ChevronDown size={14} className="text-[#1a2035] group-hover:text-primary transition-colors" />
          </div>
        ))}
      </div>

      {/* RIGHT UTILITIES */}
      <div className="flex items-center gap-x-5">
        <div className="bg-bgLight border border-borderC rounded-full px-3 py-1 flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors">
          <span className="text-[12px] font-semibold text-text-dark">EN</span>
        </div>
        <div className="flex items-center gap-x-2 cursor-pointer group">
          <Search size={18} className="text-text-dark group-hover:text-primary transition-colors" />
          <span className="text-[13px] font-medium text-text-dark group-hover:text-primary transition-colors uppercase tracking-wider">ENTER</span>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
