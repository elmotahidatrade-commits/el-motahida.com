import React from 'react';
import { Globe, Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-navy-deep text-white/70 py-[60px] px-4 md:px-[5%] w-full">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10">
        
        {/* Brand & Desc */}
        <div className="flex flex-col">
          <div className="flex items-center gap-x-2 text-white mb-4">
            <Globe className="text-primary w-6 h-6" />
            <span className="font-display font-bold text-xl tracking-tight">EL-MOTAHIDA</span>
          </div>
          <p className="text-[13px] leading-[1.6] mb-4">
            A comprehensive provider of technology solutions and turnkey manufacturing systems for industrial trade worldwide.
          </p>
        </div>

        {/* Quick Links */}
        <div className="flex flex-col">
          <h4 className="text-[16px] font-bold text-white mb-4 font-display">Quick Links</h4>
          <ul className="text-[13px] space-y-3">
            <li><a href="#" className="hover:text-primary transition-colors">About Us</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Career Opportunities</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">News & Events</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Global Network</a></li>
          </ul>
        </div>

        {/* Products */}
        <div className="flex flex-col">
          <h4 className="text-[16px] font-bold text-white mb-4 font-display">Products</h4>
          <ul className="text-[13px] space-y-3">
            <li><a href="#" className="hover:text-primary transition-colors">Turnkey Projects</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">OEM Spare Parts</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Heavy Machinery</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Automation Systems</a></li>
          </ul>
        </div>

        {/* Contact */}
        <div className="flex flex-col">
          <h4 className="text-[16px] font-bold text-white mb-4 font-display">Contact Us</h4>
          <ul className="text-[13px] space-y-4">
            <li className="flex items-start gap-x-3">
              <Phone className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <span>+20 118 964 175<br/>0473861560</span>
            </li>
            <li className="flex items-center gap-x-3">
              <Mail className="w-4 h-4 text-primary shrink-0" />
              <span>Hamedsamaha75@gmail.com</span>
            </li>
            <li className="flex items-start gap-x-3">
              <MapPin className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <span>CAIRO, EGYPT</span>
            </li>
          </ul>
        </div>

      </div>

      <div className="max-w-7xl mx-auto border-t border-white/10 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center text-[12px]">
        <p>&copy; {new Date().getFullYear()} EL-MOTAHIDA TRADE. All Rights Reserved.</p>
        <div className="flex gap-x-4 mt-4 md:mt-0">
          <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
