import React from 'react';
import { Phone, Mail } from 'lucide-react';

const Topbar = () => {
  return (
    <div className="h-[36px] bg-[#0a0f1a] w-full flex items-center px-10 text-[13px] text-white/75 gap-x-6 z-50 relative">
      <div className="flex items-center gap-x-2">
        <Phone size={14} className="text-white/75" />
        <span>+20 118 964 175</span>
      </div>
      <div className="flex items-center gap-x-2">
        <Mail size={14} className="text-white/75" />
        <span>Hamedsamaha75@gmail.com</span>
      </div>
    </div>
  );
};

export default Topbar;
